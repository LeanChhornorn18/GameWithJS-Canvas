var canvas = document.getElementById("myGame");
var context = canvas.getContext('2d');

// Score
var score = 0;
var time = 60;

// Property of big square
var x = 10;
var y = 50;
var speed = 6;
var sideLenght = 50;

// Property of target square
var targetX = 200;
var targetY = 50;
var targetLenght = 10;
var up = false;
var down = false;
var right = false;
var left = false;

function isWithin(a, b, c) {
  return (a>b && a<c);
}
function erase() {
  context.fillStyle = "#FFFFFF";
  context.fillRect(0,0,600,400);
}

function respawn() {
  targetX = Math.round(Math.random() * canvas.width - targetLenght);
  targetY = Math.round(Math.random() * canvas.height - targetLenght);
}

function draw() {
  // Clear screen
  erase();
  // Todo: Update location base on keyboard click
  if(down) {
    y += speed;
  } else if(up) {
    y -= speed;
  } else if(right) {
    x += speed;
  } else if(left) {
    x -= speed; // x = x -speed
  }

  // keep the square within the border
  if(y + sideLenght > canvas.height) {
    y = canvas.height - sideLenght;
  }
  if(x + sideLenght > canvas.width) {
    x = canvas.width - sideLenght;
  }
  if (y < 0) {
    y = 0;
  }
  if(x < 0) {
    x = 0;
  }

  // Detect if big square collides with target
  if(isWithin(targetX, x, x+sideLenght) || isWithin(targetX + targetLenght, x, x+sideLenght)) {
    if(isWithin(targetY, y, y + sideLenght) || isWithin(targetY + targetLenght, y , y+sideLenght)) {
      // Respawn target: delete old target, and random new target at other location
      respawn();
      // Increase score
      score++;
      console.log("get score", score);
    }
  }
  // Draw
  context.fillStyle = "#6FB2B8";
  context.fillRect(x, y, sideLenght, sideLenght);



  // Draw target
  context.fillStyle= "#B26FB8";
  context.fillRect(targetX, targetY, targetLenght, targetLenght);

  if(time <= 0) {
    // Game end 
  } else {
    window.requestAnimationFrame(draw);
  }
}

setInterval(function() {
  time--;
  console.log('time', time);
}, 1000);

canvas.addEventListener('keydown', function(event) {
  event.preventDefault();
  console.log(event.key);
  down = false;
  up = false;
  left = false;
  right = false;

  if(event.key == "ArrowDown") {
    down = true;
  } else if(event.key == "ArrowUp") {
    up = true;
  } else if(event.key == "ArrowLeft") {
    left = true;
  } else if(event.key == "ArrowRight") {
    right  =  true;
  }
});
function draw(){
  let startGame=document.getElementById('startGame');
  erase();
  context.beginPath();
  context.strokeStyle='blue';
  context.arc(circleX, circleY, radius, 0, 2 * Math.PI);
  context.stroke();
 
  if(circleX+radius>canvas.width||circleX-radius<0){
      dx=-dx;
  }
  if(circleY+radius>canvas.height||circleY-radius<0){
      dy=-dy;
  }
  circleY+=dy;
  circleX+=dx;

  context.fillStyle="#0000FF";
  context.fillRect(x,y,sideLenght,sideLenght);

  context.fillStyle="#F39C12";
  context.fillRect(targetX,targetY,targetLength,targetLength);

  if(count>=5){
      context.fillStyle="red";
      context.fillRect(bigTargetX,bigTargetY,bigtargetLength,bigtargetLength);
      if(isWithin(bigTargetX,x,x+sideLenght)||isWithin(bigTargetX+bigtargetLength,x,x+sideLenght)){
          if(isWithin(bigTargetY, y, y + sideLenght) || isWithin(bigTargetY +bigtargetLength , y , y+sideLenght)) {
              respawnBig();
              count=0;
              MakeOtherCircle+=1;
              time+=6;
              score+=10;
          }
      }
  }
  if(isWithin(circleX-radius,x,x+sideLenght)||isWithin(circleX+radius,x,x+sideLenght)){
      if(isWithin(circleY-radius,y,y+sideLenght)||isWithin(circleY+radius,y,y+sideLenght)){
          playAgain=false;
      }
  }
  
  if(down){
      y+=speed;
  }
  else if(up){
      y-=speed;
  }
  else if(right){
      x+=speed;
  }
  else if(left){
      x-=speed;
  }


